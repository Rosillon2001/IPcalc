package ipCalc;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class DBC {
private static DBC DB=new DBC();
private Connection conn;
private Statement stmt;
private PreparedStatement pstmt;
private ResultSet rs;
private String driverDB="org.postgresql.Driver";
private String dbName= "IpCalc";
private String urlDB="jdbc:postgresql://localhost:5432/IpCalc";
private String userDB="postgres";
private String passDB="admin";
String AA;

private DBC () {
	try {
		Class.forName(driverDB);
		this.conn=DriverManager.getConnection(urlDB,userDB,passDB);
		JFrame ventana = null;
		JOptionPane.showMessageDialog(ventana, "Bienvenido a IPCalculator\nPulse aceptar para acceder al menu\n O en su defecto cierre esta ventana");
	}catch(ClassNotFoundException | SQLException e){
		e.printStackTrace();
	}
}

public static DBC getInstances() {
	return DB;
}

public void dbClose() {
	try {
		this.conn.close();
		JFrame ventana = null;
		JOptionPane.showMessageDialog(ventana, "Conexion finalizada");
	}catch(SQLException e) {
		e.printStackTrace();
	}
}
//aniadir a la base de datos

//ipv4
public void AddIP(String query, Object[] o) {
	try {
		this.pstmt=this.conn.prepareStatement(query);
		this.pstmt.setInt(1, (int)o[0]);
		this.pstmt.setString(2, (String)o[1]);
		this.pstmt.setString(3, (String)o[2]);
		this.pstmt.setString(4, (String)o[3]);
		this.pstmt.setString(5, (String)o[4]);
		this.pstmt.setString(6, (String)o[5]);
		this.pstmt.setString(7, (String)o[6]);
		this.pstmt.setString(8, (String)o[7]);
		this.pstmt.setString(9, (String)o[8]);
		this.pstmt.setString(10, (String)o[9]);
		this.pstmt.setString(11, (String)o[10]);
		this.pstmt.setString(12, (String)o[11]);
		
		this.pstmt.executeUpdate();
	}catch(SQLException e) {
		e.printStackTrace();
	} finally {
		try {
this.pstmt.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
}
//ipv6
public void AddIP1(String query, Object[] o) {
	try {
		this.pstmt=this.conn.prepareStatement(query);
		this.pstmt.setInt(1, (int)o[0]);
		this.pstmt.setString(2, (String)o[1]);
		this.pstmt.setString(3, (String)o[2]);
		this.pstmt.setString(4, (String)o[3]);
		this.pstmt.setString(5, (String)o[4]);
		this.pstmt.setString(6, (String)o[5]);
		
		this.pstmt.executeUpdate();
	}catch(SQLException e) {
		e.printStackTrace();
	} finally {
		try {
this.pstmt.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
}


//metodo para la asignacion de ids
	public int Id(){
		
		int id=1;
		try {
			this.stmt=this.conn.createStatement();
			this.rs=this.stmt.executeQuery("SELECT MAX(id) FROM ipcalcDef");
			while(rs.next()) {
				id=rs.getInt(1)+1;
			}
			}catch(Exception e) {
			System.out.println("Error"+e.getMessage());	
			}finally {
				try {
					this.stmt.close();
					this.rs.close();
				}catch(Exception o){	
				}
			}
		return id;
	}
	
public int Id1(){
		
		int id=1;
		try {
			this.stmt=this.conn.createStatement();
			this.rs=this.stmt.executeQuery("SELECT MAX(id) FROM ipcalcDef1");
			while(rs.next()) {
				id=rs.getInt(1)+1;
			}
			}catch(Exception e) {
			System.out.println("Error"+e.getMessage());	
			}finally {
				try {
					this.stmt.close();
					this.rs.close();
				}catch(Exception o){	
				}
			}
		return id;
	}
	
	//mostrar la db
	public String mostrar () {
		try {
			this.stmt=this.conn.createStatement();
			this.rs=this.stmt.executeQuery("SELECT *FROM ipcalcDef ORDER BY id ASC");
			AA="";
			while(rs.next()) {
				AA+="-->Operacion Nro:"+rs.getInt("id")+"\n"+"-->Direccion IP:"+rs.getString("ip")+"\n"+"-->Mascara de red:"+rs.getString("mascara")+"\n"
			+"-->Clase:"+rs.getString("clase")+"\n"+"-->Tipo de IP:"+rs.getString("tipo")+"-->Protocolo APIPA:"+rs.getString("APIPA")+"\n"+
			"-->Direccion Reservada:"+rs.getString("res")+"\n"+"-->Tipo de cast o difusion:"+rs.getString("ipcast")+"\n"+
			"-->Direccion de red:"+rs.getString("net")+"\n"+"-->Direccion de Gateway"+rs.getString("gateway")+"\n"+
			"-->Direccion de Broadcast:"+rs.getString("broadcast")+"\n"+"-->Rango de IP's:"+rs.getString("rango")+"\n"+"\n";
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				this.stmt.close();
				this.rs.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		return AA;
	}
	public String mostrar1 () {
		try {
			this.stmt=this.conn.createStatement();
			this.rs=this.stmt.executeQuery("SELECT *FROM ipcalcDef1 ORDER BY id ASC");
			AA="";
			while(rs.next()) {
				AA+="-->Operacion Nro:"+rs.getInt("id")+"\n"+"-->Direccion IP ingresada="+rs.getString("ipv6IN")+"\n"+"-->Direccion IP completa="+rs.getString("ipv6OUT")
				+"\n"+"-->Mascara:"+rs.getString("mask")+"\n"+"-->Tipo de IP:"+rs.getString("tipo")+"\n"+"-->Clase o reservacion:"+rs.getString("clase")+"\n\n";
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				this.stmt.close();
				this.rs.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		return AA;
	}

}

