package ipCalc;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;

public class IpCalc1 implements ActionListener{
	DBC DB=DBC.getInstances();
	//elementos de la ui
	private JFrame ventana; private JPanel pan; private JLabel tit; private JButton hist; private JButton calc; private JButton sal;
	private JPanel op; private JPanel h; private JButton back; private JLabel Lip; private JTextField ip1; private JTextField ip2;
	private JTextField ip3; private JTextField ip4; private JButton cip1; private JButton borrar; private JTextArea historial; private JTextArea historial1;
	String history; String history1; private JScrollPane SP1;
	private JScrollPane SP; private JButton hostsb; private JButton ipv6b; private JPanel hostview; private JPanel ipv6view;
	private JTextField hosttxt; private JButton hostcalc; private JTextField ipv6txt; private JButton ipv6c; private JButton ipv6help;private JButton borraripv6;
	private JLabel historialipv4 ,historialipv6; private JLabel p1, p2, p3, slash;
	//lista desplegable y mascara de red
	private JComboBox <String> sn; String mask; String m1; String m2; String m3; String m4; private JTextField mascara; 
	int ma1; int ma2; int ma3; int ma4; String ma5; String ma6;
	//variables aux
	String s1; String s2; String s3; String s4; String clase;String tipo; String APIPA; String res; String cast; String ip;
	String b1; String b2; String b3; String b4; String ipb; 
	String Gateway; int g4; String Rango;
	int net1; int net2; int net3; int net4; String net;
	int br1; int br2; int br3; int br4; String br;
	int i1; int i2; int i3; int i4;
	int c1; int c2; int c3; int c4; 
	int k1; int k2; int k3; int k4; int k5; int k6; int k7; 
	String hip; int hip1; int hip2; int hip3; int hip4; 
	String [] ipv6; String ipv6mask=""; String ipv6dir=""; String ipv6t; String ipv6dir1="";
	String []ipv6oct; String ipv6show1; String ipv6show2; String ipv6show3; String ipv6show4; String ipv6show5; String ipv6show6; String ipv6show7; String ipv6show8;
	String []ipv6octf; int ipv6dec; String ipv6comp;  int jj; int kk; int ipv6maskint; String tipoipv6; String claseipv6; String hh;
	int o1,o2,o3,o4,o5,o6,o7,o8;
	
	int l1,l2=0,l3,l4,l5,l6,l7,l8;
	String ipv6dir2;
	int valido;
	//calculo de la mascara de red
	int hostmask; int hosts;
	//label datos de salida
	private JLabel d1;private JLabel d2;private JLabel d3;private JLabel d4;private JLabel d5;private JLabel d6;private JLabel d7;
	private JLabel d8;private JLabel d9;private JLabel d10;private JLabel d11;private JLabel d12;private JLabel d13;private JLabel d14;
	private JLabel d15;private JLabel d16;private JLabel d17;private JLabel d18;
	private JLabel ipv6tit, ipv6tit1, ipv6dirIN, ipv6dirOUT, ipv6dirl1, ipv6dirl2, ipv6dirl3, ipv6dirl4, ipv6dirl5, ipv6dirclass, ipv6dirtipo, ipv6dirmask;
	private JLabel tithost, nrohost, nrohost1, iprecomendada,iprecomendada1;
	
	
	public IpCalc1()	{
		//frame
		this.ventana=new JFrame("IpCalculator");
		this.ventana.setResizable(false);this.ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.ventana.setBounds(400, 200, 500, 500);this.ventana.setVisible(true);this.ventana.setLayout(null);
		//panel
		this.pan=new JPanel(); this.ventana.add(pan);
		this.pan.setBackground(Color.LIGHT_GRAY);this.pan.setBounds(0,0,500,500);this.pan.setVisible(true);this.pan.setLayout(null);
		this.op=new JPanel();this.ventana.add(op);
		this.op.setBackground(Color.LIGHT_GRAY);this.op.setBounds(0, 0, 500, 500);this.op.setLayout(null);this.op.setVisible(false);
		this.h=new JPanel();this.ventana.add(h);
		this.h.setBackground(Color.LIGHT_GRAY);this.h.setBounds(0, 0, 500, 500);this.h.setLayout(null);this.h.setVisible(false);
		this.hostview=new JPanel();
		this.hostview.setBackground(Color.LIGHT_GRAY);this.hostview.setBounds(0, 0, 500, 500);this.hostview.setLayout(null);this.h.setVisible(false);
		this.ipv6view=new JPanel();
		this.ipv6view.setBackground(Color.LIGHT_GRAY);this.ipv6view.setBounds(0, 0, 500, 500);this.ipv6view.setLayout(null);this.h.setVisible(false);
		//label
		this.tit=new JLabel("Menu IP");this.pan.add(tit);this.tit.setBounds(225,50,100,50);this.tit.setForeground(Color.blue);
		this.Lip=new JLabel("Direccion IPV4"); this.op.add(Lip); this.Lip.setBounds(200, 15, 200, 50);
		this.ipv6tit=new JLabel("Direccion IPv6");this.ipv6view.add(ipv6tit);this.ipv6tit.setBounds(200, 15, 200, 50);this.ipv6tit.setForeground(Color.blue);
		this.ipv6tit1=new JLabel("Formato: XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:XXXX/mascara");this.ipv6view.add(ipv6tit1);this.ipv6tit1.setBounds(60, 35, 400, 50);this.ipv6tit.setForeground(Color.blue);
		//label datos de salida ipv4
		int i=0;
		this.d1=new JLabel("Clase de IP:");this.d1.setBounds(10, 225+(i*25), 150, 40);this.op.add(d1);i++;
		this.d2=new JLabel("Tipo de IP:");this.d2.setBounds(10, 225+(i*25), 150, 40);this.op.add(d2);i++;
		this.d3=new JLabel("Protocolo APIPA:");this.d3.setBounds(10, 225+(i*25), 150, 40);this.op.add(d3);i++;
		this.d4=new JLabel("Direccion Reservada:");this.d4.setBounds(10, 225+(i*25), 150, 40);this.op.add(d4);i++;
		this.d5=new JLabel("Cast o difusion:");this.d5.setBounds(10, 225+(i*25), 150, 40);this.op.add(d5);i++;
		this.d6=new JLabel("Direccion de red:");this.d6.setBounds(10, 225+(i*25), 150, 40);this.op.add(d6);i++;
		this.d7=new JLabel("Direccion de Gateway:");this.d7.setBounds(10, 225+(i*25), 150, 40);this.op.add(d7);i++;
		this.d8=new JLabel("Direccion Broadcast:");this.d8.setBounds(10, 225+(i*25), 150, 40);this.op.add(d8);i++;
		this.d9=new JLabel("Rango de IP's:");this.d9.setBounds(10, 225+(i*25), 150, 40);this.op.add(d9);i++;
		
		int j=0;
		this.d10=new JLabel();this.d10.setBounds(200, 225+(j*25), 200, 40);this.op.add(d10);j++;
		this.d11=new JLabel();this.d11.setBounds(200, 225+(j*25), 200, 40);this.op.add(d11);j++;
		this.d12=new JLabel();this.d12.setBounds(200, 225+(j*25), 200, 40);this.op.add(d12);j++;
		this.d13=new JLabel();this.d13.setBounds(200, 225+(j*25), 200, 40);this.op.add(d13);j++;
		this.d14=new JLabel();this.d14.setBounds(200, 225+(j*25), 200, 40);this.op.add(d14);j++;
		this.d15=new JLabel();this.d15.setBounds(200, 225+(j*25), 200, 40);this.op.add(d15);j++;
		this.d16=new JLabel();this.d16.setBounds(200, 225+(j*25), 200, 40);this.op.add(d16);j++;
		this.d17=new JLabel();this.d17.setBounds(200, 225+(j*25), 200, 40);this.op.add(d17);j++;
		this.d18=new JLabel();this.d18.setBounds(200, 225+(j*25), 200, 40);this.op.add(d18);j++;
		
		//label de datos de salida ipv6
		int g=0;
		this.ipv6dirl1=new JLabel("Direccion ingresada: "); this.ipv6dirl1.setBounds(10, 200+(g*50), 200, 40);this.ipv6view.add(ipv6dirl1);g++;
		this.ipv6dirl2=new JLabel("Direccion completada: "); this.ipv6dirl2.setBounds(10, 200+(g*50), 200, 40);this.ipv6view.add(ipv6dirl2);g++;
		this.ipv6dirl3=new JLabel("Mascara: "); this.ipv6dirl3.setBounds(10, 200+(g*50), 200, 40);this.ipv6view.add(ipv6dirl3);g++;
		this.ipv6dirl4=new JLabel("Tipo de direccion: "); this.ipv6dirl4.setBounds(10, 200+(g*50), 200, 40);this.ipv6view.add(ipv6dirl4);g++;
		this.ipv6dirl5=new JLabel("Clase o reservacion: "); this.ipv6dirl5.setBounds(10, 200+(g*50), 200, 40);this.ipv6view.add(ipv6dirl5);g++;
		
		int h=0;
		this.ipv6dirIN=new JLabel(); this.ipv6dirIN.setBounds(200, 200+(h*50), 200, 40);this.ipv6view.add(ipv6dirIN);h++;
		this.ipv6dirOUT=new JLabel(); this.ipv6dirOUT.setBounds(200, 200+(h*50), 400, 40);this.ipv6view.add(ipv6dirOUT);h++;
		this.ipv6dirmask=new JLabel(); this.ipv6dirmask.setBounds(200, 200+(h*50), 200, 40);this.ipv6view.add(ipv6dirmask);h++;
		this.ipv6dirtipo=new JLabel(); this.ipv6dirtipo.setBounds(200, 200+(h*50), 400, 40);this.ipv6view.add(ipv6dirtipo);h++;
		this.ipv6dirclass=new JLabel(); this.ipv6dirclass.setBounds(200, 200+(h*50), 200, 40);this.ipv6view.add(ipv6dirclass);h++;
		
		//label de datos de host
		this.tithost=new JLabel("Ingrese el nro de host desados:");this.tithost.setBounds(165, 55, 300, 40);this.hostview.add(tithost);
		this.tithost.setForeground(Color.blue);
		int k=0;
		this.nrohost=new JLabel("Hosts deseados: ");this.nrohost.setBounds(15, 300+(k*50), 200, 40);this.hostview.add(nrohost);k++;
		this.iprecomendada=new JLabel("Ip recomendada: ");this.iprecomendada.setBounds(15, 300+(k*50), 200, 40);this.hostview.add(iprecomendada);k++;
		
		int l=0;
		this.nrohost1=new JLabel();this.nrohost1.setBounds(200, 300+(l*50), 200, 40);this.hostview.add(nrohost1);l++;
		this.iprecomendada1=new JLabel();this.iprecomendada1.setBounds(200, 300+(l*50), 200, 40);this.hostview.add(iprecomendada1);l++;
				
		//botones de opcion
		this.hist=new JButton("Historial de Operaciones");this.pan.add(hist);this.hist.setBounds(150, 150, 200, 50);this.hist.setVisible(true);
		this.hist.setBorder(BorderFactory.createLineBorder(Color.BLUE,1));this.hist.addActionListener((ActionListener)this);
		this.ipv6b=new JButton ("Calculos de Ipv6"); this.pan.add(ipv6b); this.ipv6b.setBounds(150, 200, 200, 50); this.ipv6b.setVisible(true);
		this.ipv6b.setBorder(BorderFactory.createLineBorder(Color.blue)); this.ipv6b.addActionListener((ActionListener) this);
		this.calc=new JButton("Calculos de Ipv4"); this.pan.add(calc);this.calc.setBounds(150, 250, 200, 50);this.calc.setVisible(true);
		this.calc.setBorder(BorderFactory.createLineBorder (Color.blue,1));this.calc.addActionListener((ActionListener)this);
		this.sal=new JButton ("Salir"); this.pan.add(sal);this.sal.setBounds(150, 300, 200, 50);this.sal.setVisible(true);
		this.sal.setBorder(BorderFactory.createLineBorder(Color.BLUE, 1));this.sal.addActionListener((ActionListener) this);
		this.back=new JButton("Menu"); this.back.setBounds(0, 0, 50, 50);this.back.setForeground(Color.blue);
		this.back.setBorder(BorderFactory.createLineBorder(Color.blue,1));this.back.addActionListener((ActionListener)this);
		this.cip1=new JButton("Calcular");this.cip1.setBounds(150, 175, 100, 50);this.cip1.setForeground(Color.blue);
		this.cip1.setBorder(BorderFactory.createLineBorder(Color.blue,1));
		this.borrar=new JButton("Borrar");this.borrar.setBounds(250, 175, 100, 50);this.borrar.setForeground(Color.blue);
		this.borrar.setBorder(BorderFactory.createLineBorder(Color.blue,1));
		this.hostsb=new JButton("Hosts"); this.hostsb.setBounds(370, 175, 100, 50); this.hostsb.setForeground(Color.blue);
		this.hostsb.setBorder(BorderFactory.createLineBorder(Color.blue,1));
		this.ipv6c=new JButton("Calcular"); this.ipv6c.setBounds(150, 145, 100, 50); this.ipv6c.setForeground(Color.blue);
		this.ipv6c.setBorder(BorderFactory.createLineBorder(Color.blue,1));this.ipv6c.addActionListener((ActionListener) this);
		this.hostcalc=new JButton("Calcular");this.hostcalc.setBounds(200, 175, 100, 50);this.hostcalc.setForeground(Color.blue);
		this.hostcalc.setBorder(BorderFactory.createLineBorder(Color.blue,1));
		this.borraripv6=new JButton("Borrar"); this.borraripv6.setBounds(250,145,100,50);this.borraripv6.addActionListener((ActionListener) this );
		this.borraripv6.setForeground(Color.blue); this.borraripv6.setBorder(BorderFactory.createLineBorder(Color.blue,1));this.ipv6view.add(borraripv6);
		//area de texto
		this.ip1=new JTextField();this.ip1.setBounds(100, 60, 50, 50);this.ip1.setBorder(BorderFactory.createLineBorder(Color.BLUE));this.ip1.setHorizontalAlignment(SwingConstants.CENTER);
		this.ip2=new JTextField();this.ip2.setBounds(175, 60, 50, 50);this.ip2.setBorder(BorderFactory.createLineBorder(Color.BLUE));this.ip2.setHorizontalAlignment(SwingConstants.CENTER);
		this.ip3=new JTextField();this.ip3.setBounds(250, 60, 50, 50);this.ip3.setBorder(BorderFactory.createLineBorder(Color.BLUE));this.ip3.setHorizontalAlignment(SwingConstants.CENTER);
		this.ip4=new JTextField();this.ip4.setBounds(325, 60, 50, 50);this.ip4.setBorder(BorderFactory.createLineBorder(Color.BLUE));this.ip4.setHorizontalAlignment(SwingConstants.CENTER);
		this.mascara=new JTextField();this.mascara.setBounds(400, 60, 50, 50);this.mascara.setBorder(BorderFactory.createLineBorder(Color.BLUE));this.mascara.setHorizontalAlignment(SwingConstants.CENTER);;
		this.mascara.setEditable(false);
		this.hosttxt=new JTextField();this.hosttxt.setBounds(180, 100, 140, 50); this.hosttxt.setBorder(BorderFactory.createLineBorder(Color.BLUE));
		this.hosttxt.setHorizontalAlignment(SwingConstants.CENTER);
		this.ipv6txt=new JTextField ();this.ipv6txt.setBounds(100, 80, 300, 50);this.ipv6txt.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
		this.ipv6txt.setHorizontalAlignment(SwingConstants.CENTER);
		
		//text Area y label historial de operaciones
		this.historial=new JTextArea();this.historial.setBounds(30, 60, 440, 150);this.historial.setBorder(BorderFactory.createLineBorder(Color.BLUE,1));
		this.historial.setEditable(false); this.h.add(historial);
		this.SP=new JScrollPane(historial); this.SP.setBorder(BorderFactory.createLineBorder(Color.BLUE,1));this.SP.setBounds(30, 60, 440, 150);this.h.add(SP);
		this.SP.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		this.historial1=new JTextArea();this.historial1.setBounds(30, 250, 440, 150);this.historial1.setBorder(BorderFactory.createLineBorder(Color.BLUE,1));
		this.historial1.setEditable(false); this.h.add(historial1);
		this.SP1=new JScrollPane(historial1); this.SP1.setBorder(BorderFactory.createLineBorder(Color.BLUE,1));this.SP1.setBounds(30, 250, 440, 150);this.h.add(SP1);
		this.SP1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		
		//labels historial de operaciones
		this.historialipv4=new JLabel("Operaciones en ipv4"); this.historialipv4.setBounds(200, 15, 150, 40);this.h.add(historialipv4);
		this.historialipv6=new JLabel("Operaciones en ipv6"); this.historialipv6.setBounds(200, 210, 150, 40);this.h.add(historialipv6);
		
		//Labels decorativos ipv4
		this.p1=new JLabel(".");this.p1.setBounds(160, 85, 10, 20);this.op.add(p1);
		this.p2=new JLabel(".");this.p2.setBounds(235, 85, 10, 20);this.op.add(p2);
		this.p3=new JLabel(".");this.p3.setBounds(310, 85, 10, 20);this.op.add(p3);
		this.slash=new JLabel("/");this.slash.setBounds(385, 85, 10, 20);this.op.add(slash);
		
		//JcomboBox para las mascaras de red ipv4 
		this.sn=new JComboBox<>(); sn.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "255.255.255.252  /30", "255.255.255.248  /29", "255.255.255.240  /28"
			,"255.255.255.224  /27","255.255.255.192  /26","255.255.255.128  /25","255.255.255.000  /24","255.255.254.000  /23"
			,"255.255.252.000  /22","255.255.248.000  /21","255.255.240.000  /20","255.255.224.000  /19","255.255.192.000  /18"
			,"255.255.128.000  /17","255.255.000.000  /16","255.254.000.000  /15","255.252.000.000  /14","255.248.000.000  /13"
			,"255.240.000.000  /12","255.224.000.000  /11","255.192.000.000  /10","255.168.000.000  /09","255.000.000.000  /08"
			,"254.000.000.000  /07","252.000.000.000  /06","248.000.000.000  /05","240.000.000.000  /04","224.000.000.000  /03"
			,"192.000.000.000  /02","128.000.000.000  /01"}));
		this.sn.setBounds(100, 120, 275, 50);this.sn.setBorder(BorderFactory.createLineBorder(Color.blue,1));

	}
	public void actionPerformed (ActionEvent e) { 
		if(e.getSource()==hist) {
			history=DB.mostrar();this.historial.setText(history);history1=DB.mostrar1(); this.historial1.setText(history1);
			ventana.setContentPane(h);h.setVisible(true);this.h.add(back);back.setVisible(true);
		}
		
		//boton de la vista ipv6
				if(e.getSource()==ipv6b) {
					ventana.setContentPane(ipv6view);ipv6view.setVisible(true);ipv6view.add(back);ipv6view.add(ipv6txt);ipv6view.add(ipv6c);
					this.ipv6c.addActionListener(new ActionListener () {

						public void actionPerformed(ActionEvent e) {
							ipv6calc();
						}
			});
					this.borraripv6.addActionListener(new ActionListener (){
						public void actionPerformed(ActionEvent e) {
							ipv6txt.setText(null); ipv6dirIN.setText(null);ipv6dirOUT.setText(null);ipv6dirmask.setText(null);ipv6dirtipo.setText(null);
							ipv6dirclass.setText(null);
						}
					});
		}//fin boton ipv6
				
				
		//boton calculos ipv4
		if(e.getSource()==calc) {
			ventana.setContentPane(op);op.setVisible(true);this.op.add(back);back.setVisible(true);this.op.add(Lip);Lip.setVisible(true);
			this.op.add(ip1);this.op.add(ip2);this.op.add(ip3);this.op.add(ip4);this.op.add(cip1); this.cip1.setVisible(true);
			this.op.add(borrar);this.op.add(sn); this.op.add(mascara); this.op.add(hostsb);
			
			//si se presiona calcular
			this.cip1.addActionListener(new ActionListener (){
				public void actionPerformed(ActionEvent e) {
					IPall();
				}
			});
			//si se presiona borrar
			this.borrar.addActionListener(new ActionListener() {
				public void actionPerformed (ActionEvent e ) {
					ip1.setText(null);ip2.setText(null);ip3.setText(null);ip4.setText(null);
				}
			});
			//si se presiona hosts
			this.hostsb.addActionListener(new ActionListener() {
				public void actionPerformed (ActionEvent e ) {
					ventana.setContentPane(hostview);hostview.add(back); hostview.add(hosttxt); hostview.add(hostcalc);
					hostcalc.addActionListener(new ActionListener () {
						public void actionPerformed(ActionEvent e) {
					//mascara segun hosts requeridos 
							 hh=hosttxt.getText();
							if (isNumeric(hh)) {
								hosts=Integer.parseInt(hh);
					hostmask=31-log(hosts,2);
					
					 if(hostmask <=8) {
						 hip1=10;hip2=0;hip3=0;hip4=0;
						 hip=hip1+"."+hip2+"."+hip3+"."+hip4;
						
						 
					 }
					 if(hostmask >8 && hostmask<=16) {
						 hip1=172;hip2=16;hip3=0;hip4=0;
						 hip=hip1+"."+hip2+"."+hip3+"."+hip4;
						
						 
					 }
					 if(hostmask >16 && hostmask <=30) {
						 hip1=192;hip2=168;hip3=0;hip4=0;
						 hip=hip1+"."+hip2+"."+hip3+"."+hip4;
						 
						 
					 }
					 nrohost1.setText(hh);
					 iprecomendada1.setText(hip+"/"+hostmask);
					
							}
							else {
								JOptionPane.showMessageDialog(hostview, "Ingrese un numero entero de Hosts \nEJ:55");
							}
					}		
				});
				}
			});			
		}//fin boton ipv4
		
		
		if (e.getSource()==sal) {
			ventana.dispose();DB.dbClose();
		}
		if(e.getSource()==back) {
			ventana.setContentPane(pan);
		}
		
	}
	
	
	//definicion de metodos
	
	//comprobacion de numeros enteros
	 public static boolean isNumeric(String a) {

	        boolean resultado;

	        try {
	            Integer.parseInt(a);
	            resultado = true;
	        } catch (NumberFormatException excepcion) {
	            resultado = false;
	        }

	        return resultado;
	    }
	 
	 //comprobacion de caractaeres hexadecimales
	 private static boolean Hexadecimal (String a) {
	     try {
	       Long.parseLong(a, 16);
	       return true;
	     }
	     catch (NumberFormatException excepcion) {
	       return false;
	     }
	}
	 
	 public void IPall() {
		 s1=ip1.getText();  s2=ip2.getText();  s3=ip3.getText(); s4=ip4.getText();
			if(isNumeric(s1)) {
				c1=1;
			}else {c1=0;}
			if(isNumeric(s2)) {
				c2=1;
			}else {c2=0;}
			if(isNumeric(s3)) {
				c3=1;
			}else{c3=0;}
			if(isNumeric(s4)) {
				c4=1;
			}else {c4=0;}
			if(c1==1 && c2==1 && c3==1 && c4==1) {
				ip=s1+"."+s2+"."+s3+"."+s4;
				i1=Integer.parseInt(s1);i2=Integer.parseInt(s2);i3=Integer.parseInt(s3); i4=Integer.parseInt(s4);
			}else {
				JOptionPane.showMessageDialog(op, "Dato de tipo no entero");
			}
				if((i1>=0&&i1<=255) && (i2>=0 && i2<=255) && (i3>=0 && i3<=255) && (i4>=0 && i4<=255)) {
			//mascara de red
			mask=sn.getSelectedItem().toString();
			m1=mask.substring(0, 3);m2=mask.substring(4, 7); m3=mask.substring(8, 11); m4=mask.substring(12, 15); ma5=mask.substring(18, 20);
			ma1=Integer.parseInt(m1);ma2=Integer.parseInt(m2);ma3=Integer.parseInt(m3);ma4=Integer.parseInt(m4);
			ma6=ma1+"."+ma2+"."+ma3+"."+ma4;
			mascara.setText(ma5);
			//direccion de red
			net1=i1&ma1; net2=i2&ma2; net3=i3&ma3; net4=i4&ma4;
			net=net1+"."+net2+"."+net3+"."+net4;
		
			//broadcast
			br1=((256+~ma1) | i1); br2=((256+~ma2) | i2); br3=((256+~ma3) | i3); br4=((256+~ma4) | i4);
			br=br1+"."+br2+"."+br3+"."+br4;
			//Gateway
			g4=net4+1;
			Gateway=net1+"."+net2+"."+net3+"."+g4;
			//Rango de Ip
			Rango=Gateway+" <-> "+br1+"."+br2+"."+br3+"."+(br4-1);
			
			
			
			//ip clase a
			if((i1>=0 && i1<=126) && (i2>=0 && i2<=255) && (i3>=0 && i3<=255) && (i4>=0 && i4<=255)) {
				clase="A";
				if(i1==0 && i2==0 && i3==0 && i4==0) {
					tipo=""; res="Reservada para identificacion local"; 
				}
				else if (i1==10 && (i2>=0 && i2<=255) && (i3>=0 && i3<=255) && (i4>=0 && i4<=255)) {
					tipo="Privada";res="Reservada, de tipo privada";
				}
				else {
					res="No";tipo="Publica";
				}
				k1=1; APIPA="No pertenece";
				
			}
			//ip loopback/localhost/bucle
			else if((i1==127)&&(i2>=0 && i2<=255) && (i3>=0 && i3<=255) && (i4>=0 && i4<=255)) {
				tipo="Loopback"; clase="Publica/privada";APIPA="No pertenece";
				res="Reservada, de tipo loopback"; 
				k4=1;
			}
			//ip clase b
			else if ((i1>=128 && i1<=191) && (i2>=0 && i2<=255) && (i3>=0 && i3<=255) && (i4>=0 && i4<=255)) {
				 clase="B";
				if (i1==172 && (i2>=16 && i2<=31) && (i3>=0 && i3<=255) && (i4>=0 && i4<=255)) {
					tipo="Privada";res="Reservada, de tipo privada";
				}
				else {
					tipo="Publica";
				}
				//Protocolo apipa, 169.254.0.1-169.254.255.254
				if(i1==169 && i2==254 && (i3>=0 && i3<=255) && (i4>=1 && i4<=254)) {
					APIPA="Pertenece"; res="Reservada, protocolo APIPA";tipo=""; cast="Unicast";
				}else {
					APIPA="No pertenece";res="No";
				}
				k2=1; 
			}
			//ip de clase c
			else if((i1>=192 && i1<=223) && (i2>=0 && i2<=255) && (i3>=0 && i3<=255) && (i4>=0 && i4<=255)) {
				clase="C";
				if(i1==192 && (i2==0) && (i3==2 ) && (i4>=0 && i4<=255)) {
					tipo="Test-Net 1";res="Reservada, red de pruebas"; cast="Broadcast";
				}
				else if(i1==192 && (i2==168) && (i3>=0 && i3<=255) && (i4>=0 && i4<=255)) {
					tipo="Privada";res="Reservada, de tipo privada";
				}
				else {
					tipo="Publica"; res="No";
				}
	
				k3=1; APIPA="No pertenece";
			}
			//clase d
			else if((i1>=224 && i1<=239)&& (i2>=0 && i2<=255) && (i3>=0 && i3<=255) && (i4>=0 && i4<=255)) {
				 clase="D"; tipo=""; cast="Multicast"; APIPA="No pertenece"; res="No";
				 k5=1;
			}
			//clase e
			else if((i1>=240 && i1<=255) && (i2>=0 && i2<=255) && (i3>=0 && i3<=255) && (i4>=0 && i4<=255)) {
				clase="E (experimental)";tipo="";APIPA="No pertence"; res="Reservada para usos futuros";
				if(i1==255 && i2==255 && i3==255 && i4==255) {
					cast="Broadcast";
				}
				else {
					cast="";
				}
				k6=1;
			}
			if((i1==br1)&&(i2==br2)&&(i3==br3)&&(i4==br4)) {
				cast="Broadcast";
			}
			else {
				cast="No especificado";
			}
			if(k1==1 || k2==1 || k3==1 || k4==1 || k5==1 || k6==1) {
				Object []o = {DB.Id(), ip,ma6,clase,tipo, APIPA, res, cast,net,Gateway,br,Rango};
				DB.AddIP("insert into ipcalcDef(id,ip,mascara,clase,tipo,APIPA,res,ipcast,net,gateway,broadcast,rango) values (?,?,?,?,?,?,?,?,?,?,?,?)", o);
				d10.setText(clase);d11.setText(tipo);d12.setText(APIPA);d13.setText(res);d14.setText(cast);
				d15.setText(net);d16.setText(Gateway);d17.setText(br);d18.setText(Rango);
				}
		}else {JOptionPane.showMessageDialog(op, "Rango de Ip invalido\nEl rango de ip valido es:\n0.0.0.0-255.255.255.255");
		ip1.setText(null);ip2.setText(null);ip3.setText(null);ip4.setText(null);}
	}
	 
	 //--------------------------------------------IPV6----------------------------------------------------------------------------
	 //metodo calcular ipv6
	 public void ipv6calc() {
		 ipv6t=ipv6txt.getText();
			if(ipv6t.equals("")) {
				System.out.println("No hay info");
				valido=0;
			}
			else {
				valido=1;
			ipv6= ipv6t.split("/");
			ipv6mask=ipv6[1];
			ipv6dir=ipv6[0];
			ipv6maskint=Integer.parseInt(ipv6mask);
			
			}
			if(ipv6dir.equals("") || ipv6mask.equals("")) {
				System.out.println("Sin informacion");
				valido=0;
			}else {
				if(ipv6dir.equals("::")) {
					ipv6dir1="0000:0000:0000:0000:0000:0000:0000:0000";
					l8=1;
					valido=1;
				}
				else {
					l8=3;
				}
				if(ipv6dir.equals("::1")) {
					ipv6dir1="0000:0000:0000:0000:0000:0000:0000:0001";
					l8=2;
					valido=1;
				}else {
					l8=3;
				}
				if(ipv6maskint<=0 || ipv6maskint>128) {
					JOptionPane.showMessageDialog(ipv6view, "La mascara va de 1 a 128");
					ipv6txt.setText(null);
					valido=0;
				}
				ipv6oct=ipv6dir.split(":");
				
				 l2=0;
				 for(int i=0;i<ipv6oct.length;i++) {
						if (ipv6oct[i].equals("") || l8!=3){
						}
						else {
							if(Hexadecimal(ipv6oct[i]) && ipv6oct[i].length()<=4) {
								if(ipv6oct[i].length()==4) {
							        ipv6oct[i]=ipv6oct[i];
								}
								else if(ipv6oct[i].length()==3){
									ipv6oct[i]=new StringBuilder(ipv6oct[i]).insert(0,"0").toString();
									
								}
								else if(ipv6oct[i].length()==2){
									ipv6oct[i]=new StringBuilder(ipv6oct[i]).insert(0,"00").toString();
								
								}
								else if(ipv6oct[i].length()==1){
									ipv6oct[i]=new StringBuilder(ipv6oct[i]).insert(0,"000").toString();
						
								}
										l2=l2+1;
										valido=1;
							}else {
								JOptionPane.showMessageDialog(ipv6view, "Solo se admiten bloques de 4 a 1 caracteres hexadecimales (0 a F)\n"
										+ "Ej: FA55");
								valido=0;
								ipv6txt.setText(null);
							}
						}
						
					}	
				 StringBuilder sb=new StringBuilder();
				 for(int f=0;f<ipv6oct.length;f++) {
					sb.append(ipv6oct[f]+":");
				 }
				 ipv6dir2=sb.toString();
				
				 
				 	jj=ipv6dir.indexOf("::");
					 kk=jj;
					 if(jj!=-1) {
						 ipv6dir2=sb.append(":").toString(); 
					 }else {
						 if(valido==1) {
					 ipv6dir1=ipv6dir2.substring(0,39);
						 }
					 }	
			
			
			l4=8-l2;
			
			
			l7=ipv6dir2.indexOf("::");
			 kk=l7;
			if(l7==kk && l7!=-1 && l8!=1 && l8!=2) {
				
				
					if(l4==1) {
						ipv6dir1=new StringBuilder(ipv6dir2).insert(kk+1, "0000").toString();
					}
					if(l4==2) {
						ipv6dir1=new StringBuilder(ipv6dir2).insert(kk+1, "0000:0000").toString();
					}
					if(l4==3) {
						ipv6dir1=new StringBuilder(ipv6dir2).insert(kk+1, "0000:0000:0000").toString();
					}
					if(l4==4) {
						ipv6dir1=new StringBuilder(ipv6dir2).insert(kk+1, "0000:0000:0000:0000").toString();
					}
					if(l4==5) {
						ipv6dir1=new StringBuilder(ipv6dir2).insert(kk+1, "0000:0000:0000:0000:0000").toString();
					}
					if(l4==6) {
						ipv6dir1=new StringBuilder(ipv6dir2).insert(kk+1, "0000:0000:0000:0000:0000:0000").toString();
					}
					if(l4==7) {
						ipv6dir1=new StringBuilder(ipv6dir2).insert(kk+1, "0000:0000:0000:0000:0000:0000:0000").toString();
						
					}
					if(valido==1) {
					ipv6dir1=ipv6dir1.substring(0,39);
					}
			}
			if(valido==1) {
			ipv6octf=ipv6dir1.split(":"); 
			o1=Integer.parseInt(ipv6octf[0],16);o2=Integer.parseInt(ipv6octf[1],16);o3=Integer.parseInt(ipv6octf[2],16);
			o4=Integer.parseInt(ipv6octf[3],16);o5=Integer.parseInt(ipv6octf[4],16);o6=Integer.parseInt(ipv6octf[5],16);
			o7=Integer.parseInt(ipv6octf[6],16);o8=Integer.parseInt(ipv6octf[7],16);
			}
			else {
				JOptionPane.showMessageDialog(ipv6view, "Direccion no valida");
				ipv6txt.setText(null);
			}
			
		}//final else condicional de cadena vacia
			
			//clasificacion de las redes
			if(valido==1) {
			//clasificacion unicast, anycast y multicast
			if((o1>=8192 && o1<=16283) && (o2>=0 && o2<=65535) && (o3>=0 && o3<=65535) && (o4>=0 && o4<=65535) && (o5>=0 && o5<=65535)
					&& (o6>=0 && o6<=65535) && (o7>=0 && o7<=65535) && (o8>=0 && o8<=65535)) {
				tipoipv6="Anycast o Unicast Global";
			}
			else if((o1>=65152 && o1<=65215) && (o2>=0 && o2<=65535) && (o3>=0 && o3<=65535) && (o4>=0 && o4<=65535) && (o5>=0 && o5<=65535)
					&& (o6>=0 && o6<=65535) && (o7>=0 && o7<=65535) && (o8>=0 && o8<=65535)) {
				tipoipv6="Unicast Link Local";
			}
			else if((o1==0) && (o2==0) && (o3==0) && (o4==0) && (o5==0)
					&& (o6==0) && (o7==0) && (o8==1)) {
				tipoipv6="Direccion Unicast Loopback o Localhost";
			}
			else if((o1==0) && (o2==0) && (o3==0) && (o4==0) && (o5==0)
					&& (o6==0) && (o7==0) && (o8==0)) {
				tipoipv6="Direccion Unicast sin especificar";
			}
			else if((o1>=64512 && o1<=65023) && (o2>=0 && o2<=65535) && (o3>=0 && o3<=65535) && (o4>=0 && o4<=65535) && (o5>=0 && o5<=65535)
					&& (o6>=0 && o6<=65535) && (o7>=0 && o7<=65535) && (o8>=0 && o8<=65535)) {
				tipoipv6="Unicast Unique Local";
			}
			else if((o1>=65280 && o1<=65535) && (o2>=0 && o2<=65535) && (o3>=0 && o3<=65535) && (o4>=0 && o4<=65535) && (o5>=0 && o5<=65535)
					&& (o6>=0 && o6<=65535) && (o7>=0 && o7<=65535) && (o8>=0 && o8<=65535)) {
				tipoipv6="Multicast";
			}
			else {
				tipoipv6="No especificado";
			}
			
			//clasificacion o clase de ip
			 if((o1>=0 && o1<=65535) && (o2>=0 && o2<=65535) && (o3>=0 && o3<=65535) && (o4>=0 && o4<=65535) && (o5>=0 && o5<=65535)
					&& (o6>=0 && o6<=65535) && (o7>=0 && o7<=65535) && (o8>=0 && o8<=65535)) {
				claseipv6="Ruta por defecto";
			}
			 if((o1==8193) && (o2==3512) && (o3>=0 && o3<=65535) && (o4>=0 && o4<=65535) && (o5>=0 && o5<=65535)
					&& (o6>=0 && o6<=65535) && (o7>=0 && o7<=65535) && (o8>=0 && o8<=65535)) {
				claseipv6="Documentacion y codigo";
			}
			if ((o1==8194) && (o2>=0 && o2<=65535) && (o3>=0 && o3<=65535) && (o4>=0 && o4<=65535) && (o5>=0 && o5<=65535)
					&& (o6>=0 && o6<=65535) && (o7>=0 && o7<=65535) && (o8>=0 && o8<=65535)) {
				claseipv6="Tunel 6 to 4";
			}
			ipv6dirIN.setText(ipv6dir);ipv6dirOUT.setText(ipv6dir1);ipv6dirmask.setText(ipv6mask);ipv6dirtipo.setText(tipoipv6);
			ipv6dirclass.setText(claseipv6);
			Object[] o= {DB.Id1(),ipv6dir, ipv6dir1, ipv6mask, tipoipv6, claseipv6};
			DB.AddIP1("insert into ipcalcDef1 (id, ipv6IN, ipv6OUT, mask, tipo, clase) values (?,?,?,?,?,?)", o);
	}

 }
	 //metodo para calcular los logaritmos
	private static int log(double num, int base) {
      return (int) (Math.log10(num) / Math.log10(base));
   }

}

