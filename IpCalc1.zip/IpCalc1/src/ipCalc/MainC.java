package ipCalc;

public class MainC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IpCalc1 a = new IpCalc1();
	}

}
