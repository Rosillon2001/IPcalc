module IpCalc1 {
	requires java.sql;
	requires java.desktop;
}